/*:
 ---
 # DMX
 ## Our first building block
 ---
 Lighting consoles may seem super complex, or even like magic, but when you break everything down into small blocks, things become easy to understand.

 Our first block we will try to tackle is DMX. At its core, DMX is a protocol we will be using to output data to our lights. Don't know what a protocol is? Don't worry, we will get there. First though, we will brake DMX down to a simple concept we can understand.
 
 A DMX device can be one of two things; A master or a slave. The master outputs commands. Slaves listen for commands and follows these commands. We will be building a master so we can control lights. Since DMX has multiple parts to it, we will start by turning these into smaller sections.
 
 ---
 
 ## Addresses
 
 DMX address are the instructions the master sends out to the slaves. An address has a value from 0 to 255. This isn't easy for humans to read, so lighting consoles (masters) will typically convert this into a percentage from 0 to 100.
 
 Let's build a function that does this for us:
 
 - Make a variable Int named "value" and give it any value from  0 to 255.
 - Make a fuction without a return, that takes in an Int
 - Convert your Int value you passed with some equation to a new Int called "percentageValue".
 - Have your fuction print the percentageValue out in this format: "Percentage for (value) is (percentageValue)".
 
 Pre reqs and helpful links:
 
 - [Creating a variable](https://developer.apple.com/library/content/documentation/Swift/Conceptual/Swift_Programming_Language/TheBasics.html#//apple_ref/doc/uid/TP40014097-CH5-ID309)
 - [Creating a fuction](https://developer.apple.com/library/content/documentation/Swift/Conceptual/Swift_Programming_Language/Functions.html#//apple_ref/doc/uid/TP40014097-CH10-ID158)
 - Print statements (same as fuctions)
 
 ---
*/

//Start code below this line

var value: Int = 4
func convertValueToPercentage(value:Int){
    let percentageValue = (value*100)/255
    print("Percentage for \(value) is \(percentageValue)%")
}

convertValueToPercentage(value: value)

//Reverse: From Percentage to value

var percent: Int = 2
func convertPercentageToValue(percent:Int){
    let valuePercentage = (percent*255)/100
    print("Value for \(percent)% is \(valuePercentage)")
}

convertPercentageToValue(percent: percent)
//: [Next Lesson](@next)
