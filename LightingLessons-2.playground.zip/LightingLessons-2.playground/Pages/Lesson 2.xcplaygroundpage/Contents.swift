//:[Previous Lesson](@previous)
//This isn't written yet... Don't get greedy.

//I want me to create a struc called Address and its properties will be a number that is an Int and a value that is an Int

struct Address{
    var number: Int
    var value: Int
    var percentage: Int {
        get {
            return (value*100)/255
        }
    }
}

//Now declare your first address

var firstAddress = Address(number: 1, value: 255)

firstAddress.value = 1
firstAddress.percentage

//Build a UNIVERSEEEE

struct Universe{
    var data: [Address]
    init() {
        data = []
        for i in 1...512{
            let address = Address(number: i, value: 0)
            data.append(address)
        }
        print(data)
    }
}

var firstUniverse = Universe()
firstUniverse.data[0].value = 255

print(firstUniverse.data)
